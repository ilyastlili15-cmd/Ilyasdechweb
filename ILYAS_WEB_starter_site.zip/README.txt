ILYAS WEB — prototype de boutique e-commerce bilingue

CONTENU
- index.html : site autonome responsive (HTML/CSS/JS, sans dépendances externes).
- Catalogue de démonstration, recherche, filtres par catégorie, panier conservé localement, bascule arabe/français.
- Formulaire de commande qui prépare un résumé à copier. Aucun envoi serveur n'est réalisé.

IMPORTANT AVANT LA MISE EN LIGNE
1. Remplacer les produits de démonstration par les produits réels (noms, photos, prix, variantes et stock).
2. Ajouter le vrai numéro de téléphone, e-mail, politique de confidentialité, conditions de vente, livraison/retours.
3. Connecter le formulaire à un service de réception de commandes ou à un backend sécurisé.
4. Tester le parcours sur téléphone et ordinateur.
5. Ne jamais présenter les données d'exemple comme des stocks, garanties ou services confirmés.

OUVRIR
Ouvrir index.html dans un navigateur pour une prévisualisation locale.
Pour une URL publique gratuite, déployer le dossier sur un hébergeur statique comme GitHub Pages ou Netlify (selon les conditions du service).
